<?php

define("DBPORT", "192.168.1.24");

define("DBUSER", "root");

define("DBPASS", "#47@BOM23##@");

define("DBNAME", "CRNEWS");

$con = mysql_connect(DBPORT, DBUSER, DBPASS) or die("DB ERR: Connect connecting.."); 
mysql_select_db(DBNAME, $con) or die("DB ERR: Select fail..");

?>