CREATE DATABASE CRNEWS;
USE CRNEWS;


DROP TABLE IF EXISTS `CRNEWS`.`main`;
CREATE TABLE  `CRNEWS`.`main` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(15) NOT NULL,
  `headline` varchar(100) NOT NULL DEFAULT '',
  `news` varchar(500) NOT NULL,
  `file1` varchar(200) DEFAULT NULL,
  `file2` varchar(200) DEFAULT NULL,
  `file3` varchar(200) DEFAULT NULL,
  `file4` varchar(200) DEFAULT NULL,
  `file5` varchar(200) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `CRNEWS`.`main_type`;
CREATE TABLE  `CRNEWS`.`main_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `value` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;


INSERT INTO main_type (value) VALUES ('News'), ('Image News'), ('Video News');