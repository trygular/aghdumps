<?php
	include 'config.php';
?>

<html>
<head>
    <script src="scripts/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
		html, body, table, tr {
			height: 100%;
			width: 100%;
		}
	</style>
</head>
<body>
<table>
	<tr><th>NEWS LIST</th></tr>
    <tr><td style="height:90%;">
        <ul class="list-group">
	<?php
		$perpage = 10;
		$pages_count = ceil($count / $perpage);
			
		$qrySelect = "SELECT SQL_CALC_FOUND_ROWS * FROM main"; // LIMIT ".(int)($page - 1)." ".(int)$perpage;
		$result = mysql_query($qrySelect, $con);

		//if ( mysql_num_rows($result) > 0) {
			// output data of each row
			while($row = mysql_fetch_assoc($result))
			{
				echo "<li class=\"list-group-item\"><h5><b>" . $row["headline"]. "</b></h5><p>" . $row["news"]. "</p></li>";
			}
		//} else {
		//	echo "0 results";
		//}
		mysql_close();
	?>
        </ul>
    </td></tr>
    <tr><td>
	<center>
	
	<?php
		$qrySelect = "SELECT COUNT(*) FROM main ";
		//$result = count
		$res = mysql_query($qrySelect, $con);
		
		// Get the current page or set default if not given
		$page = isset($_GET['page']) ? $_GET['page'] : 1;

		$pages_count = ceil($count / $perpage);

		$is_first = $page == 1;
		$is_last  = $page == $pages_count;

		// Prev cannot be less than one
		$prev = max(1, $page - 1);
		// Next cannot be larger than $pages_count
		$next = min($pages_count , $page + 1);

		// If we are on page 2 or higher
		if(!$is_first) {
			echo ' <a href="list_news.php?page=1" class="btn btn-primary">First</a> ';
			echo ' <a href="list_news.php?page='.$prev.'" class="btn btn-primary">Previous</a> ';
		}

		echo ' <a class="btn btn-primary">Page '.$page.' / '.$pages_count.'</a> ';

		// If we are not at the last page
		if(!$is_last) {
			echo ' <a href="list_news.php?page='.$next.'" class="btn btn-primary">Next</a> ';
			echo ' <a href="list_news.php?page='.$pages_count.'" class="btn btn-primary">Last</a> ';
		}
		
		
	?>
	</center>
	</td></tr>
</table>
</body>
</html>