<?php
function uploadFiles() {
    $num_args = func_num_args();
    $arg_list = func_get_args();
    
    $valReturn = false;
    $i = 0;
    $unlinkElement = array();
    foreach($arg_list as $key=>$value)
	{
		echo "<br />val:".is_array($value) ." - Val[0]:".is_array($value[0]);
        if(is_array($value) AND is_array($value[0]))
		{
            if($value[0]['error'] == 0 AND isset($value[1]))
			{
                if($value[0]['size'] > 0 AND $value[0]['size'] < 500000) {
                    $typeAccepted = array("image/jpeg", "image/gif", "image/png");
                    if(in_array($value[0]['type'],$typeAccepted)) {    
                        $destination = $value[1];
                        if(isset($value[2])) {
                            $extension = substr($value[0]['name'] , strrpos($value[0]['name'] , '.') +1);
                            $destination .= (str_replace(" ","-",$value[2])).".".$extension;
                        } else {
                            $destination .= $value[0]['name'];
                        }
                        
                        if(move_uploaded_file($value[0]['tmp_name'],$destination)) {
                            $i++;
                            $unlinkElement[] = $destination;
                        }
                    }
                }
            }
        }
    }
    if($i == $num_args) {
        $valReturn = true;
		
    } else {
        foreach($unlinkElement as $value) {
            unlink($value);
        }
    }
    return $unlinkElement;
}
?>

<?php

if( $_POST["submit"] == "upload" )
{
	//echo "1";
	$file_one = array($_FILES['imfImage1'],"uploads/");
	$file_two = array($_FILES['imfImage2'],"uploads/");

	$path = uploadFiles($file_one,$file_two);
	var_dump( $path );
	/*
	if(uploadFiles($file_one,$file_two)) {
		echo "true";
	} else {
		echo "false";
	}
	*/
}
?>

<form action="test.php" method="post" enctype="multipart/form-data">
	<div class="col-sm-12">
	Image 1<br /><input type="file" name="imfImage1" id="imfImage1" /><br />
	Image 2<br /><input type="file" name="imfImage2" id="imfImage2" /><br />
	</div>
	<div class="col-sm-12">
		<input type="submit" name="submit" value="upload" />
	</div>
</form>