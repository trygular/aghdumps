<!DOCTYPE html>
<html>
	<head>
        <script src="scripts/jquery-3.3.1.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js"></script>
	</head>
<body>

<?php

include ('config.php');

if( $_POST["submit"] == "News" ) {
	
	$queryInsertMain = "INSERT INTO main (type, headline, news, active) VALUES ('".$_POST["submit"]."', '".$_POST["txHeadline"]."', '".$_POST["txNews"]."', 0)";
	$result = mysql_query($queryInsertMain) or die("DB ERR: queryInsertMainTEXT");
	
	if($result)
		echo "<center>NEWS POSTED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS POSTING FAILED..</center>";

// NEWS
} else if( $_POST["submit"] == "Image News" ) {
	
	$path = "uploads/";
	$file_one = array($_FILES['imfImage1'], $path);
	$file_two = array($_FILES['imfImage2'], $path);
	$file_thr = array($_FILES['imfImage3'], $path);
	$file_fou = array($_FILES['imfImage4'], $path);
	$file_fiv = array($_FILES['imfImage5'], $path);
	
	$filePaths = uploadImage($file_one, $file_two, $file_thr, $file_fou, $file_fiv);
	
	$queryInsertMain = "INSERT INTO main (type, headline, news, file1, file2, file3, file4, file5, active)";
	$queryInsertMain .=" VALUES ";
	$queryInsertMain .="('".$_POST["submit"]."', '".$_POST["imHeadline"]."', '".$_POST["imNews"]."', '".$filePaths[0]."', '".$filePaths[1]."', '".$filePaths[2]."', '".$filePaths[3]."', '".$filePaths[4]."', 0)";
	$result = mysql_query($queryInsertMain) or die("DB ERR: queryInsertMainIMAGE");

	if($result)
		echo "<center>NEWS POSTED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS POSTING FAILED..</center>"; 
	
//IMAGE	
} else if( $_POST["submit"] == "Video News" ) {
	
	$path = "uploads/";
	$file_one = array($_FILES['vifVideo1'], $path);
	$file_two = array($_FILES['vifVideo2'], $path);
	$file_thr = array($_FILES['vifVideo3'], $path);
	$file_fou = array($_FILES['vifVideo4'], $path);
	$file_fiv = array($_FILES['vifVideo5'], $path);
	
	$filePaths = uploadVideo($file_one, $file_two, $file_thr, $file_fou, $file_fiv);
	
	$queryInsertMain = "INSERT INTO main (type, headline, news, file1, file2, file3, file4, file5, active)";
	$queryInsertMain .=" VALUES ";
	$queryInsertMain .="('".$_POST["submit"]."', '".$_POST["viHeadline"]."', '".$_POST["viNews"]."', '".$filePaths[0]."', '".$filePaths[1]."', '".$filePaths[2]."', '".$filePaths[3]."', '".$filePaths[4]."', 0)";
	$result = mysql_query($queryInsertMain) or die("DB ERR: queryInsertMainVIDEO");

	if($result)
		echo "<center>NEWS POSTED SUCCESSFULLY..</center>";
	else
		echo "<center>NEWS POSTING FAILED..</center>";

//VIDEO	
}

function uploadImage() {
    $num_args = func_num_args();
    $arg_list = func_get_args();
    
    $valReturn = false;
    $i = 0;
    $unlinkElement = array();
    foreach($arg_list as $key=>$value)
	{
		//echo "<br />val:".is_array($value) ." - Val[0]:".is_array($value[0]);
        if(is_array($value) AND is_array($value[0]))
		{
            if($value[0]['error'] == 0 AND isset($value[1]))
			{
                if($value[0]['size'] > 0 AND $value[0]['size'] < 500000) {
                    $typeAccepted = array("image/jpeg", "image/gif", "image/png");
                    if(in_array($value[0]['type'],$typeAccepted)) {    
                        $destination = $value[1];
                        if(isset($value[2])) {
                            $extension = substr($value[0]['name'] , strrpos($value[0]['name'] , '.') +1);
                            $destination .= (str_replace(" ","-",$value[2])).".".$extension;
                        } else {
                            $destination .= $value[0]['name'];
                        }
                        
                        if(move_uploaded_file($value[0]['tmp_name'],$destination)) {
                            $i++;
                            $unlinkElement[] = $destination;
                        }
                    }
                }
            }
        }
    }
    if($i == $num_args) {
        $valReturn = true;
		
    } /*else {
        foreach($unlinkElement as $value) {
            unlink($value);
        }
    }*/
    return $unlinkElement;
}

function uploadVideo() {
    $num_args = func_num_args();
    $arg_list = func_get_args();
    
    $valReturn = false;
    $i = 0;
    $unlinkElement = array();
    foreach($arg_list as $key=>$value)
	{
        if(is_array($value) AND is_array($value[0]))
		{
            if($value[0]['error'] == 0 AND isset($value[1]))
			{
                if($value[0]['size'] > 0 AND $value[0]['size'] < 900000)
				{
                    $typeAccepted = array("video/mp4");
                    if(in_array($value[0]['type'],$typeAccepted)) {    
                        $destination = $value[1];
                        if(isset($value[2])) {
                            $extension = substr($value[0]['name'] , strrpos($value[0]['name'] , '.') +1);
                            $destination .= (str_replace(" ","-",$value[2])).".".$extension;
                        } else {
                            $destination .= $value[0]['name'];
                        }
                        
                        if(move_uploaded_file($value[0]['tmp_name'],$destination)) {
                            $i++;
                            $unlinkElement[] = $destination;
                        }
                    }
                }
            }
        }
    }
    if($i == $num_args) {
        $valReturn = true;
		
    } /*else {
        foreach($unlinkElement as $value) {
            unlink($value);
        }
    }*/
    return $unlinkElement;
}

?>

<form action="upload.php" method="post" enctype="multipart/form-data">
	<ul class="list-group" style="width:100%;">

		<!-- TEXT -->
		<li class="list-group-item"><a href="#demo1" data-toggle="collapse" data-target="#demo1">TEXT</a>
			<div id="demo1" class="collapse in">
				
				<!-- bs grid -->
				<div class="row">
					<div class="col-sm-12">Hedline<br /><input type="text" name="txHeadline" id="txHeadline" placeholder="News headline here..." /></div>
				</div>
				<div class="row">
					<div class="col-sm-12">Description<br /><textarea type="text" name="txNews" id="txNews" placeholder="News description here..."></textarea></div>
				</div>
				<div class="row">
					<div class="col-sm-12"><input type="submit" name="submit" value="News"></div>
				</div>
				
			</div>
		</li>

		<!-- IMAGE -->
		<li class="list-group-item"><a href="#demo2" data-toggle="collapse" data-target="#demo2">IMAGE</a>
			<div id="demo2" class="collapse">
				
				<!-- bs grid -->
				<div class="row">
					<div class="col-sm-12">Hedline<br /><input type="text" name="imHeadline" id="imHeadline" placeholder="News headline here..." /></div>
				</div>
				<div class="row">
					<div class="col-sm-12">Description<br /><textarea type="text" name="imNews" id="imNews" placeholder="News description here..."></textarea></div>
				</div>
				<div class="row">
					<div class="col-sm-12">
					Image 1<br /><input type="file" name="imfImage1" id="imfImage1" /><br />
					Image 2<br /><input type="file" name="imfImage2" id="imfImage2" /><br />
					Image 3<br /><input type="file" name="imfImage3" id="imfImage3" /><br />
					Image 4<br /><input type="file" name="imfImage4" id="imfImage4" /><br />
					Image 5<br /><input type="file" name="imfImage5" id="imfImage5" /><br />
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12"><input type="submit" name="submit" value="Image News"></div>
				</div>
				
			</div>
		</li>

		<!-- VIDEO -->
		<li class="list-group-item"><a href="#demo3" data-toggle="collapse" data-target="#demo3">VIDEO</a>
			<div id="demo3" class="collapse">
				
				<!-- bs grid -->
				<div class="row">
					<div class="col-sm-12">Hedline<br /><input type="text" name="viHeadline" id="viHeadline" placeholder="News headline here..." /></div>
				</div>
				<div class="row">
					<div class="col-sm-12">Description<br /><textarea type="text" name="viNews" id="viNews" placeholder="News description here..."></textarea></div>
				</div>
				<div class="row">
					<div class="col-sm-12">
					Video 1<br /><input type="file" name="vifVideo1" id="vifVideo1" /><br />
					Video 2<br /><input type="file" name="vifVideo2" id="vifVideo2" /><br />
					Video 3<br /><input type="file" name="vifVideo3" id="vifVideo3" /><br />
					Video 4<br /><input type="file" name="vifVideo4" id="vifVideo4" /><br />
					Video 5<br /><input type="file" name="vifVideo5" id="vifVideo5" /><br />
				</div>
				<div class="row">
					<div class="col-sm-12"><input type="submit" name="submit" value="Video News"></div>
				</div>
				
			</div>
		</li>

	</ul>
</form>

</body>
</html>