<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>Login</title>
</head>
<body>

<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
  <tr>
    <td>
      <table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
      <form name="" method="post">
        <tr>
          <td colspan="3" align="center"><strong>User Login </strong></td>
        </tr>
        <tr>
          <td width="78">Username</td>
          <td width="6">:</td>
          <td width="294"><input name="username" type="text" id="username"></td>
        </tr>
        <tr>
          <td>Password</td>
          <td>:</td>
          <td><input name="password" type="password" id="password"></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>
            <input type="submit" name="submit" value="Login" />
            <input type="reset" name="reset" value="reset" />
          </td>
        </tr>
      </form>

      </table>
    </td>
  </tr>
</table>

<?php
if (isset($_POST['submit']))
{
  include("config.php");

  $query = mysql_query("SELECT * FROM login WHERE username='".$_POST['username']."' and password='".$_POST['password']."' ");

  if (mysql_num_rows($query) != 0) {
      include("database.class.php");
      include("session.php");
      $session = new Session();
      //Store variable as usual
      $_SESSION['user'] = ;
      //Show stored user
      echo $_SESSION['user'];

      echo "<script language='javascript' type='text/javascript'> location.href='home.php'; </script>";	
  } else {
    // mysql_num_rows($query) == 0
    echo "<script type='text/javascript'>alert('User Name Or Password Invalid!')</script>";
  }
}
?>
</body>
</html>
