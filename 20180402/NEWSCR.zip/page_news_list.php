<?php
	include 'config.php';
?>

<html>
<head>
    <script src="scripts/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
		html, body, table, tr {
			height: 100%;
			width: 100%;
		}
		center { color:#FFF; }
		.imgSize { width:90px; height:90px; }
	</style>
</head>
<body style="background: rgb(63, 65, 148);">
<div class="container">
	<table>

		<tr><td style="height:90%;">
			<ul class="list-group">
			
		<?php
			$perpage = 10;
			$pages_count = ceil($count / $perpage);
				
			$qrySelect = "SELECT SQL_CALC_FOUND_ROWS * FROM main"; // LIMIT ".(int)($page - 1)." ".(int)$perpage;
			$result = mysql_query($qrySelect, $con);

			//if ( mysql_num_rows($result) > 0) {
				// output data of each row
				while($row = mysql_fetch_assoc($result))
				{
					if($row["headline"] != null && $row["news"] != null)
					{
						echo "<li class=\"list-group-item\"><h5><b>" . $row["headline"]. "</b></h5><p>" . $row["news"]. "<br/>";
					
						if($row["type"] == "Post Image News")
						{
							if($row["file1"] != null)
							{
								echo "<br/><img src='" . $row["file1"]. "' class='imgSize' />";
								if($row["file2"] != null)
								{
									echo "<br/><img src='" . $row["file2"]. "' class='imgSize' />";
									if($row["file3"] != null)
									{
										echo "<br/><img src='" . $row["file3"]. "' class='imgSize' />";
										if($row["file4"] != null)
										{
											echo "<br/><img src='" . $row["file4"]. "' class='imgSize' />";
											if($row["file5"] != null)
											{
												echo "<br/><img src='" . $row["file5"]. "' class='imgSize' />";
											}
										}
									}
								}
							}
						} else if($row["type"] == "Post Video News") {
							if($row["file1"] != null)
							{
								echo "<br/><a href='" . $row["file1"]. "'>View Video 1</a>";
								if($row["file2"] != null)
								{
									echo "<br/><a href='" . $row["file2"]. "'>View Video 2</a>";
									if($row["file3"] != null)
									{
										echo "<br/><a href='" . $row["file3"]. "'>View Video 3</a>";
										if($row["file4"] != null)
										{
											echo "<br/><a href='" . $row["file4"]. "'>View Video 4</a>";
											if($row["file5"] != null)
											{
												echo "<br/><a href='" . $row["file5"]. "'v>View Video 5</a>";
											}
										}
									}
								}
							}
						}
						echo "</p></li>";
					}
				}
			//} else {
			//	echo "0 results";
			//}
			mysql_close();
		?>
			</ul>
		</td></tr>
		
<!-- footer -->
		<tr><td>
		<center>
		
		<?php
			$qrySelect = "SELECT COUNT(*) FROM main ";
			//$result = count
			$res = mysql_query($qrySelect, $con);
			
			// Get the current page or set default if not given
			$page = isset($_GET['page']) ? $_GET['page'] : 1;

			$pages_count = ceil($count / $perpage);

			$is_first = $page == 1;
			$is_last  = $page == $pages_count;

			// Prev cannot be less than one
			$prev = max(1, $page - 1);
			// Next cannot be larger than $pages_count
			$next = min($pages_count , $page + 1);

			// If we are on page 2 or higher
			if(!$is_first) {
				echo ' <a href="page_news_list.php?page=1" class="btn btn-primary">First</a> ';
				echo ' <a href="page_news_list.php?page='.$prev.'" class="btn btn-primary">Previous</a> ';
			}

			echo ' <a class="btn btn-primary">Page '.$page.' / '.$pages_count.'</a> ';

			// If we are not at the last page
			if(!$is_last) {
				echo ' <a href="page_news_list.php?page='.$next.'" class="btn btn-primary">Next</a> ';
				echo ' <a href="page_news_list.php?page='.$pages_count.'" class="btn btn-primary">Last</a> ';
			}
			
			
		?>
		</center>
		</td></tr>
	</table>
</div>
</body>
</html>