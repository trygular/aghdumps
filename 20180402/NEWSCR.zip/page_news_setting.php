<?php
	include 'config.php';
?>

<html>
<head>
    <script src="scripts/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
		html, body, table, tr {
			height: 100%;
			width: 100%;
		}
		center { color:#FFF; }
	</style>
</head>
<body style="background: rgb(63, 65, 148);">

<div class="container">
	<table>
		<tr>
			<td style="height:90%;">
				<ul class="list-group">
					<li class="list-group-item">
						<a href="page_news_setting.php">Settings</a>
					</li>
					<li class="list-group-item">
						<a href="">Change Username</a>
					</li>
					<li class="list-group-item">
						<a href="">Change Password</a>
					</li>
					<li class="list-group-item">
						<a href="">Change Password</a>
					</li>
					<li class="list-group-item">
						<a href="">Edit News</a>
					</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td></td>
		</tr>
	</table>
</div>

</body>
</html>