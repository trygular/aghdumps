<?php
	include 'config.php';
	
?>

<html>
<head>
    <script src="scripts/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
		html, body, table, tr {
			height: 100%;
			width: 100%;
		}
		center { color:#FFF; }
	</style>

	<!-- style for collapse other tabs -->
	<script>
	  $(function () {
        $('.panel-collapse').on('show.bs.collapse', function (e) {
            $(e.target).closest('.panel').siblings().find('.panel-collapse').collapse('hide');
        });
    });
	</script>
</head>
<body style="background: rgb(63, 65, 148);">

<?php

$pro_name = "";
$pro_mobi = "";

include("session.php");
$session = new Session();

if(!isset($_POST["submit"]) && isset($_SESSION["user"]))
{
	$sql = "SELECT username, password, name, mobile FROM login WHERE username='".$_SESSION["user"]."' ";
	$result = mysql_query($sql, $con);
	$row = mysql_fetch_row($result);
	$flag_show = 1;
	$pro_name = $row[2];
	$pro_mobi = $row[3];
} else {
	$flag_show = 0;
}

if($_POST["submit"] == "Login")
{
	//select txUser and txPass
	$sql = "SELECT username, password, name, mobile FROM login WHERE username='".$_POST["txUser"]."' AND password='".$_POST["txPass"]."' ";
	if ($result = mysql_query($sql, $con))
	{
		$flag_show = mysql_num_rows($result);
		if($flag_show != 0)
		{
			$row = mysql_fetch_row($result);
			{
				$_SESSION["user"] = $row[0];
				$pro_name = $row[2];
				$pro_mobi = "+91-".$row[3];
			}
		} else {
			// username or password missmatch.
			echo "<center>Invalid username or password..!</center>";
		}
	} else {
		// DB : Error in retriving user info
		echo "<center>DB ERR: Error in retriving user info..!</center>";
	}
}

if($_POST["submit"] == "Sign Up")
{
	$sql0 = "INSERT INTO login (username, password, name, mobile) VALUES ('".$_POST["txUser"]."', '".$_POST["txPass"]."','".$_POST["txName"]."','".$_POST["txMobi"]."') ";
	if($result0 = mysql_query($sql0, $con))
	{
		$flag_show = 2;

		$sql = "SELECT username, password, name, mobile FROM login WHERE username='".$_POST["txUser"]."' AND password='".$_POST["txPass"]."' ";
		if ($result = mysql_query($sql, $con))
		{
			if(mysql_num_rows($result) != 0)
			{
				$row = mysql_fetch_row($result);
				{
					$_SESSION["user"] = $row[0];
					$pro_name = $row[2];
					$pro_mobi = "+91-".$row[3];
				}
			} else {
				// username or password missmatch.
				echo "<center>Invalid username or password..!</center>";
			}
		}
	} else {
		// DB: Error in creation user info
		echo "<center>DB ERR: Error in creating user info..!</center>";
	}
}

?>

	<div class="container">

		<table>
	<?php
		if($flag_show == 0) {			// USER login fails	
	?>
			<tr>
				<td style="height:90%;">
					<ul class="list-group">
						<li class="list-group-item">

						<div class="row panel">
							<div class="col-sm-12">
								<div role="tab" id="headingTwo">
									<a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
										<h6 class="">Signup / Register</h6>
									</a>
									<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">

										<form action="page_profile.php" method="POST">
											<div class="row form-group">
												<div class="col-sm-12">Name<br /><input type="text" name="txName" id="txName" class="form-control" placeholder="Name" /></div>
											</div> 
											<div class="row form-group">
												<div class="col-sm-12">Username<br /><input type="text" name="txUser" id="txUser" class="form-control" placeholder="Desired username" />
											</div>
											</div> 
											<div class="row form-group">
												<div class="col-sm-12">Mobile<br /><input type="number" name="txMobi" id="txMobi" class="form-control" placeholder="Mobile" /></div>
											</div> 
											<div class="row form-group">
												<div class="col-sm-12">Password<br /><input type="password" name="txPass" id="txPass" class="form-control" placeholder="Password" /></div>
											</div> 
											<div class="row form-group">
												<div class="col-sm-12">Confirm Password<br /><input type="password" name="txPassConf" id="txPassConf" class="form-control" placeholder="Confirm Password" /></div>
											</div> 
											<div class="row form-group">
												<div class="col-sm-12" style="text-align:right;"><input type="submit" class="btn btn-default" name="submit" value="Sign Up"></div>
											</div>
										</form>

									</div>  <!-- frmSignup -->
								</div> <!-- tab 2 -->
							</div><!-- col --> 
						</div> <!-- row -->

						<div class="row panel">
							<div class="col-sm-12">
								<div role="tab" id="headingOne">
									<a class="btnTabLogin" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
										<h6>Login</h6>
									</a>
									<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">

										<form action="page_profile.php" method="POST">
											<div class="row">
												<div class="col-sm-4"></div>
												<div class="col-sm-4"></div>
												<div class="col-sm-4"></div>
											</div>
											<div class="row form-group">
												<div class="col-sm-12">Username<br /><input type="text" name="txUser" id="txUser" class="form-control" placeholder="Username" /></div>
											</div> 
											<div class="row form-group">
												<div class="col-sm-12">Password<br /><input type="password" name="txPass" id="txPass" class="form-control" placeholder="Password" /></div>
											</div> 
											<div class="row">
												<div class="col-sm-12" style="text-align:right;"><input type="submit" id="btnLogin" class="btn btn-default" name="submit" value="Login"></div>
											</div>
										</form>

									</div>  <!-- frmLogin -->
								</div> <!-- tab 1 -->
							</div><!-- col --> 
						</div> <!-- row -->

						</li>
					</ul>
				</td>
			</tr>
	<?php
		} else if($flag_show == 1) {	// USER is here from login 
	?>
			<tr>
				<ul class="list-group">
					<li class="list-group-item">
						<div class="row">
							<div class="col-xs-6">Username : </div>
							<div class="col-xs-6">
						<?php
							if(!isset($_SESSION["user"])) {
								header("Location : page_profile.php");	
							}
							echo $_SESSION["user"];
						?>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6">Name : </div>
							<div class="col-xs-6"><?php echo $pro_name; ?></div>
						</div>
						<div class="row">
							<div class="col-xs-6">Mobile : </div>
							<div class="col-xs-6"><?php echo $pro_mobi; ?></div>
						</div>
						<div class="row">
							<div class="col-xs-12"><a href="logout.php">Logout</a></div>
						</div>
					</li>
				</ul>
			</tr>
	<?php
		} else if($flag_show == 2) {	// USER is here from signup & is logged in for first time
	?>
			<tr>
				<ul class="list-group">
					<li class="list-group-item">
						<div class="row">
							<div class="col-xs-6">Username : </div>
							<div class="col-xs-6">
						<?php
							if(!isset($_SESSION["user"])) {
								header("Location : page_profile.php");	
							}
							echo $_SESSION["user"];
						?>
							</div>
						</div>
						<div class="row">
							<div class="col-xs-6">Name : </div>
							<div class="col-xs-6"><?php echo $pro_name; ?></div>
						</div>
						<div class="row">
							<div class="col-xs-6">Mobile : </div>
							<div class="col-xs-6"><?php echo $pro_mobi; ?></div>
						</div>
						<div class="row">
							<div class="col-xs-12"><a href="logout.php">Logout</a></div>
						</div>
					</li>
				</ul>
			</tr>
	<?php
		}
	?>
			<tr>
				<td>
					<h1></h1>
				</td>
			</tr><!-- footer -->
		</table>
	</div>


</body>
</html>