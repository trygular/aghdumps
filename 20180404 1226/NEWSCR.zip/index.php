<html>
    <head>
        <style>
            html, body, table, tr {
                height: 100%;
                width: 100%;
            }
            body {
                height:99%;
            }
            td {
                width:50px;
            }
            #tab_head {
                width:100%;
                height:10%;
            }
            #tab_body {
                width:100%;
                height:80%;
            }
            #tab_foot {
                width:100%;
                height:10%;
            }
            .apptitle
            {
                 color:#fff;
                 font-size:15pt;
            }

            li:hover { color:#FFF; background-color:Gray; }

            r1 {
                width: 150px;
                height: 80px;
                -ms-transform: rotate(270deg); /* IE 9 */
                -webkit-transform: rotate(270deg); /* Safari 3-8 */
                transform: rotate(270deg);
            }
            r2 {
                width: 150px;
                height: 80px;
                -ms-transform: rotate(330deg); /* IE 9 */
                -webkit-transform: rotate(330deg); /* Safari 3-8 */
                transform: rotate(330deg);
            }
            r3 {
                width: 150px;
                height: 80px;
                -ms-transform: rotate(300deg); /* IE 9 */
                -webkit-transform: rotate(300deg); /* Safari 3-8 */
                transform: rotate(300deg);
            }
            r4 {
                transform: rotate(30deg);
                -ms-transform: rotate(30deg); /* IE 9 */
                -webkit-transform: rotate(30deg); /* Safari and Chrome */
                -o-transform: rotate(30deg); /* Opera */
                -moz-transform: rotate(30deg); /* Firefox */
            }

            .txcenter { text-align: center; }

            a { width:100%; }
        </style>

        <script src="scripts/jquery-3.3.1.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body style="background: rgb(63, 65, 148);">
	
	<center> <a href="./apk/tarunbharat.apk" class="btn btn-info">Download Mobile App</a> </center>
	
        <table>
            <tr>
                <td id="tab_body">
                    <center><img id="logo_channel" src="images\logo_channel.png" /></center>
                </td>
            </tr>
            <tr>
                <td id="tab_foot2">
                    <ul class="list-group">
                        <a href=""><li class="list-group-item"></li></a>
                        <a href=""><li class="list-group-item"></li></a>
                        <a href=""><li class="list-group-item"></li></a>
                        <a href=""><li class="list-group-item"></li></a>
                    </ul>
                </td>
            </tr>
        </table>
    </body>
    <script>
        $(document).ready(function(){

            //btn_Settings click
            $("#btnSettings").click(function(){

            });
        });
    </script>
</html>
