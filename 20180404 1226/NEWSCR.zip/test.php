
<?php
if($_POST['Action']=="Send_SMS")
{
//Your authentication key
$authKey = "1eb155da72b53245fb32b05532b4de";

//Multiple mobiles numbers separated by comma
$mobileNumber = $_POST['mobileno'];

//Sender ID,While using route4 sender id should be 6 characters long.
$senderId = $_POST['smsservice'];

//Your message to send, Add URL encoding here.
$message = urlencode($_POST['msg']);
 if($_POST['smstype']==1)
$unicode=1;
else
$unicode=0;

//Define route 
$route = 4;
//Prepare you post parameters
$postData = array(
    'authkey' => $authKey,
    'mobiles' => $mobileNumber,
    'message' => $message,
    'sender' => $senderId, 
	'route' => $route,
	'unicode' => $unicode
	
);
echo $postData;
//API URL
$url="http://sms.belgaumit.com/sendhttp.php";

// init the resource
$ch = curl_init();
curl_setopt_array($ch, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postData
    //,CURLOPT_FOLLOWLOCATION => true
));


//Ignore SSL certificate verification
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);


//get response
$output = curl_exec($ch);

//Print error if any
if(curl_errno($ch))
{
    echo 'error:' . curl_error($ch);
}

curl_close($ch);

echo $output;
}



?>
<html>
<form action='test.php' method='post'>
<center>
<table width='50%'>
<tr><td colspan=2 align='center' ><font size='7'>Tarun Bharat </font><font color='brown' size='7'>SMS Portal</font> </td></tr>
<tr><td colspan=2 align='center'><img src='images/sms123.jpg' width=50% height=50%></img></td></tr>
<tr><td width='50%' align='right'><font color='brown' size='4'> SMS Type : </td><td width='50%'>
<select name='smstype' >
<option value='0'>English</option>
<option value='1'>Marathi Unicode</option>
</select>

</td></tr>
<tr><td width='50%' align='right'><font color='brown' size='4'> SMS Service : </td><td width='50%'>
<select name='smsservice' >
<option value='TARUNB'>TARUN BHARAT</option>
<option value='LOKHRD'>LOKMANYA </option>
</select>

</td></tr>
<tr><td width='50%' align='right'>Paste Your Mobile No : </td><td width='50%'><textarea type='text' name='mobileno' id='mobileno' rows=3 cols=40></textarea><br><br></td></tr>

<tr><td align='right'>Paste Your Message : </td><td><textarea type='text' name='msg' id='msg' rows=3 cols=40></textarea> <br><br></td></tr>
<tr><td colspan=2 align='center'><input type='submit' name='Action' value='Send_SMS'></td></tr>
</form>
</html>
