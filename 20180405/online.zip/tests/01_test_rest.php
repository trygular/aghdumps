<?php

if($_SERVER['REQUEST_METHOD'] == "POST"){
	// Get data
	$name = isset($_POST['name']) ? mysql_real_escape_string($_POST['name']) : "";
	$email = isset($_POST['email']) ? mysql_real_escape_string($_POST['email']) : "";
	$password = isset($_POST['pwd']) ? mysql_real_escape_string($_POST['pwd']) : "";
	$status = isset($_POST['status']) ? mysql_real_escape_string($_POST['status']) : "";

	
    $json = array("status" => 1, "msg" => "Done User added! - ".$_POST[0] );
	
}else{
	$json = array("status" => 0, "msg" => "Request method not accepted");
}


/* Output header */
header('Content-type: application/json');
echo json_encode($json);

?>