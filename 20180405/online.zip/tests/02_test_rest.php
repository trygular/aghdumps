<?php

foreach (getallheaders() as $name => $value) {
    echo "$name: $value\n";
}

?>