package abh.volleytest01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Button b1, b2, b3, b4;
    private Button b5, b6, b7, b8;
    private EditText t1, t2, etMulti1;

    private String url = "http://circulation.tbdnet/php/";
    private String urlB1, urlB2, urlB3, urlB4, urlB5, urlB6, urlB7, urlB8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // buttons for volley String Request
        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        b4 = (Button) findViewById(R.id.b4);

        // buttons for volley JsonObject Request
        b5 = (Button) findViewById(R.id.b5);
        b6 = (Button) findViewById(R.id.b6);
        b7 = (Button) findViewById(R.id.b7);
        b8 = (Button) findViewById(R.id.b8);

        t1 = (EditText) findViewById(R.id.et1);
        t2 = (EditText) findViewById(R.id.et2);

        etMulti1 = (EditText) findViewById(R.id.etMulti1);

        urlB1 = "b1.php";
        urlB2 = "b2.php";
        urlB3 = "b3.php";
        urlB4 = "b4.php";
        urlB5 = "b5.php";
        urlB6 = "b6.php";
        urlB7 = "b7.php";
        urlB8 = "b8.php";

        // VOLLEY POST - String Request - SEND {string, number, boolean} and RECIEVE {string, number, boolean}
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            try {
                final String username = "JACK";
                final String password = "SPARROW";

                StringRequest stringRequest = new StringRequest(Request.Method.POST, (url + urlB1),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //do stuffs with response of post
                        etMulti1.setText(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //do stuffs with response erroe
                        etMulti1.setText(error.toString());
                    }
                }){
                    @Override
                    protected Map<String,String> getParams(){
                        Map<String,String> params = new HashMap<String, String>();
                        params.put("password",password);
                        params.put("username", username);
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            } catch (Exception e) {
                e.printStackTrace();
            }
            }
        });

        // VOLLEY POST - String Request - SEND {array} and RECIEVE {array}
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            try {
                final String username = "JACK";
                final String password = "SPARROW";

                StringRequest stringRequest = new StringRequest(Request.Method.POST, (url + urlB2),
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //do stuffs with response of post
                                etMulti1.setText(response);
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                //do stuffs with response erroe
                                etMulti1.setText(error.toString());
                            }
                        }){
                    @Override
                    protected Map<String,String> getParams(){
                        Map<String,String> params = new HashMap<String, String>();
                        params.put("password",password);
                        params.put("username", username);
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            } catch (Exception e) {
                e.printStackTrace();
            }
            }
        });

        // VOLLEY POST - String Request - SEND {object} and RECIEVE {object}
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            try {
                final String username = "JACK";
                final String password = "SPARROW";

                StringRequest stringRequest = new StringRequest(Request.Method.POST, (url + urlB3),
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //do stuffs with response of post
                                etMulti1.setText(response);
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                //do stuffs with response erroe
                                etMulti1.setText(error.toString());
                            }
                        }){
                    @Override
                    protected Map<String,String> getParams(){
                        Map<String,String> params = new HashMap<String, String>();
                        params.put("password",password);
                        params.put("username", username);
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            } catch (Exception e) {
                e.printStackTrace();;
            }
            }
        });

        // VOLLEY POST - String Request - SEND {null} and RECIEVE {null}
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            try {
                final String username = "JACK";
                final String password = "SPARROW";

                StringRequest stringRequest = new StringRequest(Request.Method.POST, (url + urlB4),
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //do stuffs with response of post
                                etMulti1.setText(response);
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                //do stuffs with response erroe
                                etMulti1.setText(error.toString());
                            }
                        }){
                    @Override
                    protected Map<String,String> getParams(){
                        Map<String,String> params = new HashMap<String, String>();
                        params.put("password",password);
                        params.put("username", username);
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                requestQueue.add(stringRequest);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            }
        });






        // VOLLEY POST - JsonObject Request - SEND {string, number, boolean} and RECIEVE {string, number, boolean}
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                    // POST parameters
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("tag", "test");
                    JSONObject jsonObj = new JSONObject(params);
                    // Request a json response from the provided URL
                    JsonObjectRequest jsonObjRequest = new JsonObjectRequest(Request.Method.POST, (url + urlB5), jsonObj, new Response.Listener<JSONObject>()
                    {
                        @Override
                        public void onResponse(JSONObject response)
                        {
                            // Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                            etMulti1.setText(response.toString());
                        }
                    },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    // Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                                    etMulti1.setText(error.toString());
                                }
                            });
                    // Add the request to the RequestQueue.
                    queue.add(jsonObjRequest);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // VOLLEY POST - JsonObject Request - SEND {array} and RECIEVE {array}
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                    // POST parameters
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("tag", "test");
                    JSONObject jsonObj = new JSONObject(params);
                    // Request a json response from the provided URL
                    JsonObjectRequest jsonObjRequest = new JsonObjectRequest(Request.Method.POST, (url + urlB6), jsonObj, new Response.Listener<JSONObject>()
                    {
                        @Override
                        public void onResponse(JSONObject response)
                        {
                            // Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                            etMulti1.setText(response.toString());
                        }
                    },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    // Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                                    etMulti1.setText(error.toString());
                                }
                            });
                    // Add the request to the RequestQueue.
                    queue.add(jsonObjRequest);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        // VOLLEY POST - JsonObject Request - SEND {object} and RECIEVE {object}
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                    // POST parameters
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("tag", "test");
                    JSONObject jsonObj = new JSONObject(params);
                    // Request a json response from the provided URL
                    JsonObjectRequest jsonObjRequest = new JsonObjectRequest(Request.Method.POST, (url + urlB7), jsonObj, new Response.Listener<JSONObject>()
                    {
                        @Override
                        public void onResponse(JSONObject response)
                        {
                            // Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                            etMulti1.setText(response.toString());
                        }
                    },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    // Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                                    etMulti1.setText(error.toString());
                                }
                            });
                    // Add the request to the RequestQueue.
                    queue.add(jsonObjRequest);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        // VOLLEY POST - JsonObject Request - SEND {null} and RECIEVE {null}
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    RequestQueue queue = Volley.newRequestQueue(getApplicationContext());

                    // POST parameters
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("tag", "test");
                    JSONObject jsonObj = new JSONObject(params);

                    // Request a json response from the provided URL
                    JsonObjectRequest jsonObjRequest = new JsonObjectRequest(Request.Method.POST, (url + urlB8), jsonObj, new Response.Listener<JSONObject>()
                    {
                        @Override
                        public void onResponse(JSONObject response)
                        {
                            // Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                            etMulti1.setText(response.toString());
                        }
                    },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error)
                                {
                                    // Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                                    etMulti1.setText(error.toString());
                                }
                            });
                    // Add the request to the RequestQueue.
                    queue.add(jsonObjRequest);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
}
