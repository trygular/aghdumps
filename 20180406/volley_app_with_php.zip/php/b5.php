<?php

$response = array("tag" => $_POST["tag"]);
echo json_encode($response);

?>